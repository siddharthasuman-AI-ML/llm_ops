"""RAG system implementation with Gemini embeddings and FAISS"""
import os
from pathlib import Path
from typing import List, Dict
from langchain_community.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from agent.app.config import (
    GEMINI_API_KEY, EMBEDDING_MODEL, KNOWLEDGE_DIR, 
    VECTORSTORE_PATH, CHUNK_SIZE, CHUNK_OVERLAP, TOP_K
)


class RAGSystem:
    """RAG system for customer knowledge retrieval"""
    
    def __init__(self):
        """Initialize RAG system with embeddings and vectorstore"""
        self.embeddings = GoogleGenerativeAIEmbeddings(
            model=EMBEDDING_MODEL,
            google_api_key=GEMINI_API_KEY
        )
        self.vectorstore = None
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=CHUNK_SIZE,
            chunk_overlap=CHUNK_OVERLAP,
            length_function=len,
        )
    
    def load_documents(self) -> List[Document]:
        """Load all customer markdown files as documents"""
        documents = []
        knowledge_path = Path(KNOWLEDGE_DIR)
        
        if not knowledge_path.exists():
            raise FileNotFoundError(f"Knowledge directory not found: {KNOWLEDGE_DIR}")
        
        # Load all markdown files
        for md_file in sorted(knowledge_path.glob("*.md")):
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
                # Create document with metadata
                doc = Document(
                    page_content=content,
                    metadata={"source": str(md_file.name)}
                )
                documents.append(doc)
        
        return documents
    
    def build_vectorstore(self, force_rebuild: bool = False):
        """Build or load FAISS vectorstore"""
        # Check if vectorstore exists
        if VECTORSTORE_PATH.exists() and not force_rebuild:
            try:
                self.vectorstore = FAISS.load_local(
                    str(VECTORSTORE_PATH.parent),
                    self.embeddings,
                    allow_dangerous_deserialization=True,
                    index_name="faiss_index"
                )
                print(f"Loaded existing vectorstore from {VECTORSTORE_PATH}")
                return
            except Exception as e:
                print(f"Error loading vectorstore: {e}. Rebuilding...")
        
        # Build new vectorstore
        print("Building vectorstore from knowledge base...")
        documents = self.load_documents()
        
        if not documents:
            raise ValueError("No documents found in knowledge directory")
        
        # Split documents into chunks
        texts = self.text_splitter.split_documents(documents)
        print(f"Split {len(documents)} documents into {len(texts)} chunks")
        
        # Create FAISS vectorstore
        self.vectorstore = FAISS.from_documents(texts, self.embeddings)
        
        # Save vectorstore
        VECTORSTORE_PATH.parent.mkdir(parents=True, exist_ok=True)
        self.vectorstore.save_local(
            str(VECTORSTORE_PATH.parent),
            index_name="faiss_index"
        )
        print(f"Saved vectorstore to {VECTORSTORE_PATH}")
    
    def retrieve(self, query: str, k: int = TOP_K) -> List[Document]:
        """Retrieve relevant documents for a query"""
        if self.vectorstore is None:
            self.build_vectorstore()
        
        # Retrieve similar documents
        docs = self.vectorstore.similarity_search(query, k=k)
        return docs
    
    def retrieve_with_scores(self, query: str, k: int = TOP_K) -> List[tuple]:
        """Retrieve documents with similarity scores"""
        if self.vectorstore is None:
            self.build_vectorstore()
        
        # Retrieve with scores
        docs_with_scores = self.vectorstore.similarity_search_with_score(query, k=k)
        return docs_with_scores
    
    def get_context(self, query: str) -> str:
        """Get formatted context string from retrieved documents"""
        docs = self.retrieve(query)
        context_parts = []
        
        for i, doc in enumerate(docs, 1):
            context_parts.append(f"[Document {i}]\n{doc.page_content}\n")
        
        return "\n".join(context_parts)


# Global RAG instance
_rag_instance = None

def get_rag_system() -> RAGSystem:
    """Get or create RAG system instance"""
    global _rag_instance
    if _rag_instance is None:
        _rag_instance = RAGSystem()
        _rag_instance.build_vectorstore()
    return _rag_instance

