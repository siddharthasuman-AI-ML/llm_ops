"""Utility functions for CRM Agent"""
import re
from typing import List, Dict, Any

def chunk_text(text: str, chunk_size: int = 300, overlap: int = 80) -> List[str]:
    """Simple text chunking function"""
    words = text.split()
    chunks = []
    current_chunk = []
    current_size = 0
    
    for word in words:
        word_size = len(word) + 1  # +1 for space
        if current_size + word_size > chunk_size and current_chunk:
            chunks.append(' '.join(current_chunk))
            # Overlap: keep last N words
            overlap_words = current_chunk[-overlap:] if len(current_chunk) > overlap else current_chunk
            current_chunk = overlap_words + [word]
            current_size = sum(len(w) + 1 for w in current_chunk)
        else:
            current_chunk.append(word)
            current_size += word_size
    
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    
    return chunks

def extract_metadata_from_filename(filename: str) -> Dict[str, Any]:
    """Extract metadata from customer markdown filename"""
    match = re.search(r'CUST-(\d+)', filename)
    if match:
        return {"customer_id": f"CUST-{match.group(1).zfill(3)}"}
    return {}

