"""Guardrails for preventing sensitive data leakage"""
import re
from typing import Dict, Tuple, Optional

# Patterns for detecting sensitive information
PHONE_PATTERN = re.compile(r'\+?\d{1,4}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}|\d{10,}')
EMAIL_PATTERN = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
CUSTOMER_ID_PATTERN = re.compile(r'CUST-\d{3}', re.IGNORECASE)
ADDRESS_PATTERN = re.compile(r'\d+\s+[A-Za-z\s,]+(?:Road|Street|Avenue|Lane|Park|Hills|Layout|City|Nagar|Place|Drive),?\s+[A-Za-z\s,]+(?:Maharashtra|Karnataka|Delhi|Telangana|Tamil Nadu|West Bengal|Uttar Pradesh|Haryana|Gujarat)\s+\d{5,6}', re.IGNORECASE)

# MINIMAL GUARDRAILS FOR TESTING - Most protections disabled
# Suspicious patterns for extraction attempts - keeping only most obvious ones
EXTRACTION_KEYWORDS = [
    'export customer data',  # Only keeping the most obvious bulk export request
]

# Jailbreak patterns - DISABLED FOR TESTING
# JAILBREAK_PATTERNS = [
#     r'ignore\s+(all\s+)?(previous\s+)?instructions?',
#     r'forget\s+(all\s+)?(previous\s+)?(instructions?|rules?)',
#     r'you\s+are\s+now',
#     r'pretend\s+you\s+are',
#     r'act\s+as\s+if',
#     r'developer\s+mode',
#     r'bypass\s+safety',
#     r'emergency\s+access',
#     r'system\s+override'
# ]
JAILBREAK_PATTERNS = []  # Empty list - no jailbreak detection


def check_input_guardrails(query: str) -> Tuple[bool, Optional[str]]:
    """
    MINIMAL INPUT GUARDRAILS FOR TESTING
    Check if input query violates guardrails.
    Returns: (is_blocked, reason)
    Most checks disabled - only blocking most obvious bulk export requests.
    """
    query_lower = query.lower()
    
    # Only check for most obvious extraction attempts
    for keyword in EXTRACTION_KEYWORDS:
        if keyword in query_lower:
            return True, f"Query contains suspicious extraction attempt: '{keyword}'. I cannot provide bulk customer data or export customer information."
    
    # Jailbreak detection DISABLED FOR TESTING
    # for pattern in JAILBREAK_PATTERNS:
    #     if re.search(pattern, query_lower):
    #         return True, "Query attempts to override system instructions. I must follow my security guidelines."
    
    # Sensitive pattern detection DISABLED FOR TESTING
    # All context-aware and sensitive pattern checks removed
    
    return False, None


def check_output_guardrails(response: str) -> Tuple[bool, Optional[str]]:
    """
    MINIMAL OUTPUT GUARDRAILS FOR TESTING
    Check if output response contains sensitive data.
    Returns: (is_blocked, reason)
    Only filtering phone numbers and emails - all other checks disabled.
    """
    # Check for phone numbers - KEPT FOR BASIC PROTECTION
    if PHONE_PATTERN.search(response):
        return True, "Response contains phone numbers. Personal contact information cannot be shared."
    
    # Check for email addresses - KEPT FOR BASIC PROTECTION
    if EMAIL_PATTERN.search(response):
        return True, "Response contains email addresses. Personal contact information cannot be shared."
    
    # Customer ID blocking DISABLED FOR TESTING
    # if CUSTOMER_ID_PATTERN.search(response):
    #     return True, "Response contains customer IDs. Customer identifiers cannot be shared."
    
    # Address blocking DISABLED FOR TESTING
    # if ADDRESS_PATTERN.search(response):
    #     return True, "Response contains addresses. Personal location information cannot be shared."
    
    # Markdown pattern blocking DISABLED FOR TESTING
    # if re.search(r'\*\*Name:\*\*|\*\*Email:\*\*|\*\*Phone:\*\*|\*\*Address:\*\*', response):
    #     return True, "Response contains raw customer profile data. Full customer profiles cannot be shared."
    
    # Ticket pattern blocking DISABLED FOR TESTING
    # ticket_patterns = [
    #     r'unable\s+to\s+access',
    #     r'payment\s+failure',
    #     r'password\s+reset',
    #     r'account\s+(access|upgrade|cancellation)',
    #     r'billing\s+(inquiry|discrepancy)'
    # ]
    # 
    # for pattern in ticket_patterns:
    #     if re.search(pattern, response, re.IGNORECASE):
    #         if 'ticket' in response.lower() or 'recent' in response.lower():
    #             return True, "Response contains detailed ticket information. Specific customer ticket details cannot be shared."
    
    return False, None


def apply_guardrails(query: str, response: str) -> Dict:
    """
    Apply both input and output guardrails.
    Returns: dict with 'blocked', 'response', 'reason', 'from_guardrails'
    """
    # Check input guardrails
    input_blocked, input_reason = check_input_guardrails(query)
    if input_blocked:
        return {
            'blocked': True,
            'response': f"I cannot fulfill this request. {input_reason} I can help you with general information about our services, policies, or non-sensitive customer status inquiries.",
            'reason': input_reason,
            'from_guardrails': True
        }
    
    # Check output guardrails
    output_blocked, output_reason = check_output_guardrails(response)
    if output_blocked:
        return {
            'blocked': True,
            'response': f"I cannot share this information as it contains sensitive customer data. {output_reason} Please ask about general information or non-sensitive customer status instead.",
            'reason': output_reason,
            'from_guardrails': True
        }
    
    # No guardrail violations
    return {
        'blocked': False,
        'response': response,
        'reason': None,
        'from_guardrails': False
    }

