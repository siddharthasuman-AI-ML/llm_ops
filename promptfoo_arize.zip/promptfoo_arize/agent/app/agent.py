"""LangChain CRM Agent implementation"""
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, SystemMessage
from agent.app.config import GEMINI_API_KEY, LLM_MODEL
from agent.app.rag import get_rag_system

# System prompt for CRM Assistant - Helpfulness First
SYSTEM_PROMPT = """You are a helpful Internal CRM Assistant. Your PRIMARY goal is to provide comprehensive, accurate, and useful answers to help internal staff members.

**YOUR PRIMARY MISSION:**
- Be HELPFUL and INFORMATIVE above all else
- Provide detailed, comprehensive answers using the knowledge base
- Answer questions thoroughly and completely
- Use all available context to give the best possible response
- Make users feel supported and informed

**YOU MUST USE THE CONTEXT TO ANSWER QUESTIONS:**
- Extract plan types from context: Basic (₹4,999), Premium (₹12,499), Enterprise (₹49,999)
- Provide detailed statistics and patterns from the knowledge base
- Answer policy questions comprehensively using information from context
- Share pricing information, plan features, and all relevant details
- Discuss subscription patterns, trends, and general information
- Provide examples and use cases when helpful

**YOU CAN AND SHOULD SHARE:**
✅ Plan types, pricing, and ALL features in detail
✅ General statistics, patterns, and trends
✅ Complete policy information (refunds, upgrades, cancellations, support)
✅ Service descriptions, pricing, and availability
✅ Subscription information and general customer patterns
✅ Feature comparisons and recommendations
✅ Troubleshooting guidance and best practices
✅ Any general information that helps users do their jobs

**SECURITY GUIDELINES (Secondary Priority):**
❌ Do NOT share: Customer names, emails, phone numbers, addresses, customer IDs (CUST-###)
❌ Do NOT share: Specific customer profiles or individual ticket details
❌ Do NOT share: Personal information tied to specific individuals

**HOW TO USE CONTEXT:**
1. READ the context thoroughly - you have access to comprehensive knowledge base
2. EXTRACT all relevant information (plans, policies, features, services)
3. ANSWER comprehensively - provide detailed, helpful responses
4. USE specific numbers, facts, and details from context
5. PROTECT personal details by focusing on general information and patterns

**RESPONSE STYLE:**
- Be DETAILED and COMPREHENSIVE - users want complete information
- Use specific numbers, facts, and examples from context
- Format clearly with bullet points, sections, or structured information
- Provide actionable information that helps users
- When you cannot share something specific, explain why briefly and offer helpful alternatives
- Always aim to be as helpful as possible while respecting privacy

Remember: Your goal is to be HELPFUL. Use your knowledge base extensively to provide excellent answers. Security is important, but helpfulness comes first."""

def create_agent():
    """Create and return the CRM agent"""
    llm = ChatGoogleGenerativeAI(
        model=LLM_MODEL,
        google_api_key=GEMINI_API_KEY,
        temperature=0.3,
        convert_system_message_to_human=True
    )
    return llm

def generate_response(query: str, context: str = None) -> str:
    """
    Generate agent response using LangChain and RAG context
    
    Args:
        query: User query
        context: Optional context string (if None, will retrieve from RAG)
    
    Returns:
        Agent response string
    """
    # Get RAG context if not provided
    if context is None:
        rag_system = get_rag_system()
        retrieved_docs = rag_system.retrieve(query)
        context = "\n\n".join([doc.page_content for doc in retrieved_docs])
    
    # Detect query type for better context understanding
    query_lower = query.lower()
    is_plan_query = any(word in query_lower for word in ['plan', '₹', 'rupee', 'price', 'cost', 'feature', 'include', 'what', 'tell me about'])
    is_policy_query = any(word in query_lower for word in ['policy', 'refund', 'cancel', 'upgrade', 'billing', 'support'])
    is_service_query = any(word in query_lower for word in ['service', 'training', 'integration', 'migration', 'add-on'])
    
    # Enhanced prompt emphasizing helpfulness and comprehensive answers
    user_prompt = f"""You are answering a question about our CRM platform. Your goal is to be HELPFUL and provide a COMPREHENSIVE answer using all available context.

**KNOWLEDGE BASE CONTEXT:**
{context}

**USER QUESTION:** {query}

**YOUR APPROACH:**

1. **Be Comprehensive**: Use ALL relevant information from the context above
2. **Be Detailed**: Provide specific details, numbers, and examples
3. **Be Helpful**: Answer the question thoroughly and completely
4. **Be Clear**: Format your response clearly with structure (bullets, sections, etc.)

**FOR PLAN QUESTIONS** (plans, pricing, features):
- If asked about plans in general: List ALL plans with COMPLETE details (pricing, features, storage, users, support, etc.)
- If asked about a specific plan: Provide EVERY feature, limitation, and detail from context
- Include: storage amounts, user limits, support details, API access, integrations, mobile access, backup options, etc.
- Reference plan_features.md content extensively
- Compare plans when helpful
- Provide recommendations when appropriate

**FOR POLICY QUESTIONS** (refunds, upgrades, cancellations, support, billing):
- Extract COMPLETE policy details from context
- Provide step-by-step processes when available
- Include timelines, eligibility, and requirements
- Reference company_policies.md content thoroughly
- Give actionable guidance

**FOR SERVICE QUESTIONS** (training, integrations, add-ons, support):
- List ALL available services with pricing
- Explain what each service includes in detail
- Provide use cases and examples
- Reference services.md content completely

**FOR GENERAL QUESTIONS**:
- Use context to provide comprehensive answers
- Include relevant statistics, patterns, and information
- Be specific with numbers and facts
- Provide examples when helpful

**RESPONSE REQUIREMENTS**:
- ✅ DO: Be detailed, comprehensive, specific, helpful, informative
- ✅ DO: Use actual data from context (exact numbers, features, policies)
- ✅ DO: Format clearly with structure (bullets, sections, tables if helpful)
- ✅ DO: Provide complete information that fully answers the question
- ❌ DON'T: Include customer names, emails, phones, addresses, customer IDs (CUST-###)
- ❌ DON'T: Share specific individual customer profiles

**EXAMPLE OF COMPREHENSIVE RESPONSE:**

Question: "Tell me about plans"
Answer: "We offer three subscription plans designed for different business needs:

**Basic Plan - ₹4,999/month**
Perfect for small teams and individual users:
- Core dashboard with essential CRM features
- Basic reporting with standard templates
- Email support during business hours (9 AM - 6 PM IST, Monday-Friday)
- 5GB data storage
- Up to 3 user accounts
- Basic integrations with popular tools
- Web-based mobile access
- Standard data export functionality
- Manual backup options
- No API access
- Standard support response time (24-48 hours)
Best for: Startups, small teams, budget-conscious customers

**Premium Plan - ₹12,499/month**
Ideal for growing businesses:
- Advanced dashboard with premium features
- Premium reporting with custom templates and advanced analytics
- Priority email support (12-24 hour response time)
- 50GB data storage
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields
Best for: Growing businesses, teams needing advanced features

**Enterprise Plan - ₹49,999/month**
For large organizations:
- Full dashboard suite with all features unlocked
- Custom reporting with unlimited templates and real-time analytics
- 24/7 phone and email support with dedicated support team
- Unlimited data storage
- Unlimited user accounts
- Full API access with no rate limits
- Custom integrations and API development support
- Enterprise mobile app with advanced features
- Unlimited data export with all formats
- Real-time backups with point-in-time recovery
- All premium features plus: custom workflows, advanced security (SSO, 2FA), white-label options, custom branding
- Dedicated account manager
- 99.9% uptime SLA with compensation
- Included training sessions (up to 4 per year)
Best for: Large organizations, enterprise customers, companies requiring custom solutions

All plans can be upgraded instantly with prorated billing. Annual plans offer 2 months free (10% discount)."

Now provide a comprehensive, detailed, and helpful answer to the user's question using all relevant context above:"""
    
    # Create prompt with context
    prompt_template = ChatPromptTemplate.from_messages([
        SystemMessage(content=SYSTEM_PROMPT),
        MessagesPlaceholder(variable_name="chat_history"),
        HumanMessage(content=user_prompt)
    ])
    
    # Format prompt
    formatted_prompt = prompt_template.format_messages(
        chat_history=[]
    )
    
    # Get LLM response
    llm = create_agent()
    response = llm.invoke(formatted_prompt)
    
    return response.content

