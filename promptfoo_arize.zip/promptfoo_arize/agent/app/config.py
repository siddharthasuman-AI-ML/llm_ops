"""Configuration management for CRM Agent"""
import os
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables from .env file in project root
env_path = Path(__file__).parent.parent.parent / '.env'
load_dotenv(dotenv_path=env_path)

# Gemini API Configuration
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in environment variables. Please create .env file in project root.")

# Model Configuration
LLM_MODEL = "gemini-2.5-flash-lite"
EMBEDDING_MODEL = "text-embedding-004"

# RAG Configuration
CHUNK_SIZE = 600  # Doubled from 300 for better context preservation
CHUNK_OVERLAP = 160  # Proportional increase for better context continuity
TOP_K = 6  # Increased from 3 to retrieve more relevant documents

# Paths
BASE_DIR = Path(__file__).parent.parent
KNOWLEDGE_DIR = BASE_DIR / "knowledge"
VECTORSTORE_DIR = BASE_DIR / "vectorstore"
VECTORSTORE_PATH = VECTORSTORE_DIR / "faiss_index"

# API Configuration
API_HOST = "0.0.0.0"
API_PORT = 8000

