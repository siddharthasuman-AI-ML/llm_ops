"""FastAPI backend for CRM Agent"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import logging

from agent.app.agent import generate_response
from agent.app.guardrails import apply_guardrails

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="CRM Internal Agent API",
    description="Internal CRM Assistant API with guardrails",
    version="1.0.0"
)

# Add CORS middleware for Streamlit
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request/Response models
class ChatRequest(BaseModel):
    query: str


class ChatResponse(BaseModel):
    response: str
    from_guardrails: bool


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "CRM Internal Agent API",
        "version": "1.0.0",
        "endpoints": {
            "/chat": "POST - Chat with CRM agent"
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy"}


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Chat endpoint for CRM agent
    
    Request:
        {
            "query": "string"
        }
    
    Response:
        {
            "response": "string",
            "from_guardrails": bool
        }
    """
    try:
        query = request.query.strip()
        
        if not query:
            raise HTTPException(status_code=400, detail="Query cannot be empty")
        
        logger.info(f"Received query: {query[:100]}...")
        
        # Apply guardrails to input
        guardrail_result = apply_guardrails(query, "")
        
        # If input is blocked, return guardrail response
        if guardrail_result['blocked']:
            logger.info("Query blocked by input guardrails")
            return ChatResponse(
                response=guardrail_result['response'],
                from_guardrails=True
            )
        
        # Generate agent response
        try:
            agent_response = generate_response(query)
            logger.info(f"Generated agent response: {agent_response[:100]}...")
        except Exception as e:
            logger.error(f"Error generating agent response: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"Error generating response: {str(e)}"
            )
        
        # Apply guardrails to output
        final_result = apply_guardrails(query, agent_response)
        
        # Return response
        return ChatResponse(
            response=final_result['response'],
            from_guardrails=final_result['from_guardrails']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    from agent.app.config import API_HOST, API_PORT
    
    uvicorn.run(
        "agent.app.main:app",
        host=API_HOST,
        port=API_PORT,
        reload=True
    )

