"""Script to initialize the vectorstore"""
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from agent.app.rag import get_rag_system

if __name__ == "__main__":
    print("Initializing vectorstore...")
    print("This may take a few minutes as it processes all customer files...")
    
    try:
        rag_system = get_rag_system()
        rag_system.build_vectorstore(force_rebuild=True)
        print("\n✅ Vectorstore initialized successfully!")
        print(f"Location: {rag_system.vectorstore}")
    except Exception as e:
        print(f"\n❌ Error initializing vectorstore: {e}")
        sys.exit(1)

