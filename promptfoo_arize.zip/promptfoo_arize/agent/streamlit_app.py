"""Streamlit UI for CRM Agent"""
import streamlit as st
import requests
from typing import Dict, List

# API Configuration
API_URL = "http://localhost:8000/chat"

# Page configuration
st.set_page_config(
    page_title="CRM Internal Agent",
    page_icon="🤖",
    layout="wide"
)

# Initialize session state
if "messages" not in st.session_state:
    st.session_state.messages = []
if "api_status" not in st.session_state:
    st.session_state.api_status = "unknown"

def check_api_health() -> bool:
    """Check if API is running"""
    try:
        response = requests.get("http://localhost:8000/health", timeout=2)
        return response.status_code == 200
    except:
        return False

def send_message(query: str) -> Dict:
    """Send message to API and get response"""
    try:
        response = requests.post(
            API_URL,
            json={"query": query},
            timeout=30
        )
        response.raise_for_status()
        return response.json()
    except requests.exceptions.ConnectionError:
        return {
            "response": "❌ Error: Cannot connect to API. Please make sure the FastAPI server is running on http://localhost:8000",
            "from_guardrails": False
        }
    except Exception as e:
        return {
            "response": f"❌ Error: {str(e)}",
            "from_guardrails": False
        }

# Header
st.title("🤖 CRM Internal Agent")
st.markdown("**Internal CRM Assistant with Privacy Guardrails**")

# Sidebar
with st.sidebar:
    st.header("ℹ️ Information")
    st.markdown("""
    This is an internal CRM assistant that helps with customer inquiries while maintaining strict data privacy.
    
    **Features:**
    - Customer status inquiries
    - Policy information
    - General CRM assistance
    
    **Privacy:**
    - Personal customer data is protected
    - Guardrails prevent data leakage
    - Only non-sensitive information is shared
    """)
    
    st.divider()
    
    # API Status
    st.subheader("API Status")
    api_healthy = check_api_health()
    if api_healthy:
        st.success("✅ API Connected")
    else:
        st.error("❌ API Not Connected")
        st.info("Please start the FastAPI server:\n```bash\npython -m agent.app.run_server\n```")
    
    st.divider()
    
    # Clear chat button
    if st.button("🗑️ Clear Chat History"):
        st.session_state.messages = []
        st.rerun()

# Main chat interface
if not api_healthy:
    st.warning("⚠️ **API Server Not Running**")
    st.info("""
    To start the API server, run the following command in your terminal:
    
    ```bash
    python -m agent.app.run_server
    ```
    
    Or:
    
    ```bash
    uvicorn agent.app.main:app --reload
    ```
    """)

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message.get("from_guardrails"):
            st.info("🛡️ Guardrail Protection Active")

# Chat input
if prompt := st.chat_input("Ask a question about customers or policies..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Get response from API
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response_data = send_message(prompt)
            response_text = response_data.get("response", "No response received")
            from_guardrails = response_data.get("from_guardrails", False)
        
        st.markdown(response_text)
        
        if from_guardrails:
            st.info("🛡️ **Guardrail Protection**: This response was filtered by security guardrails.")
    
    # Add assistant message to chat history
    st.session_state.messages.append({
        "role": "assistant",
        "content": response_text,
        "from_guardrails": from_guardrails
    })

# Footer
st.divider()
st.markdown(
    "<small>CRM Internal Agent v1.0 | Built with FastAPI, LangChain, and Gemini</small>",
    unsafe_allow_html=True
)

