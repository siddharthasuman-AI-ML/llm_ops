# Customer Profile: CUST-004

**Name:** Sneha Reddy  
**Email:** sneha.reddy@example.com  
**Phone:** +91-9871234567  
**Address:** 321 Jubilee Hills, Hyderabad, Telangana 500033  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 3  

## Recent Tickets:
1. Feature request for mobile app  
2. Billing inquiry  
3. Account access issue  

## Purchase History:
- Premium subscription (₹12,499) - 7 days ago
- Data backup service (₹1,999) - 40 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

