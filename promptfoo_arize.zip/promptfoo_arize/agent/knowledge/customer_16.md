# Customer Profile: CUST-016

**Name:** Neha Shah  
**Email:** neha.shah@example.com  
**Phone:** +91-9123456784  
**Address:** 579 Viman Nagar, Pune, Maharashtra 411014  
**Plan Type:** Basic  
**Last Purchase:** ₹4,999  
**Open Tickets:** 1  

## Recent Tickets:
1. Account cancellation inquiry  

## Purchase History:
- Basic subscription (₹4,999) - 120 days ago

## Plan Features Access:
**Basic Plan Features:**
- Core dashboard with essential features
- Basic reporting with standard templates
- Email support during business hours (9 AM - 6 PM IST, Monday-Friday)
- 5GB data storage
- Up to 3 user accounts
- Basic integrations with popular tools
- Web-based mobile access
- Standard data export functionality
- Manual backup options

