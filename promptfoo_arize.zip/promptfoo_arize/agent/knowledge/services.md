# Additional Services

## Overview
Beyond our core subscription plans, we offer a range of additional services to help you get the most out of our platform. These services are available to customers on all plans.

---

## Training Services

### Onboarding Training - ₹5,000
**Duration:** 2-hour session  
**Includes:**
- Platform overview and navigation
- Basic feature walkthrough
- Account setup assistance
- Q&A session
- Training materials and documentation

**Best For:** New customers getting started

### Advanced Training - ₹8,000
**Duration:** 4-hour session  
**Includes:**
- Advanced features deep dive
- Workflow optimization
- Best practices and tips
- Custom use case guidance
- Follow-up support (1 week)

**Best For:** Teams wanting to maximize platform usage

### Enterprise Training Package - ₹25,000
**Duration:** Multiple sessions (up to 16 hours total)  
**Includes:**
- Customized training curriculum
- Multiple team sessions
- Role-specific training
- Ongoing support (1 month)
- Training materials and certifications

**Best For:** Large organizations training multiple teams

### Training Delivery Options
- **Live Online**: Video conference sessions
- **On-Site**: Available for Enterprise customers (additional travel costs)
- **Recorded**: Session recordings available upon request
- **Group Sessions**: Up to 10 participants per session

---

## Custom Integration Services

### Standard Integration - ₹15,000
**Includes:**
- Integration with one third-party service
- API connection setup
- Basic data synchronization
- Testing and validation
- Documentation

**Timeline:** 2-3 weeks  
**Examples:** CRM integrations, email marketing tools, accounting software

### Advanced Integration - ₹30,000
**Includes:**
- Complex multi-service integration
- Custom API development
- Advanced data mapping
- Workflow automation
- Extended testing period
- 3 months support

**Timeline:** 4-6 weeks  
**Examples:** ERP systems, custom databases, proprietary systems

### Enterprise Integration Package - Custom Pricing
**Includes:**
- Multiple integrations
- Custom API development
- Dedicated integration specialist
- Ongoing maintenance
- SLA guarantee
- Priority support

**Timeline:** Custom based on requirements  
**Best For:** Enterprise customers with complex integration needs

### Integration Support
- **Consultation**: Free consultation to assess integration needs
- **Documentation**: Complete integration documentation provided
- **Support**: 3-6 months support included (varies by package)
- **Updates**: Integration updates as APIs change

---

## Data Migration Services

### Standard Migration - ₹6,999
**Includes:**
- Data export from source system
- Data cleaning and validation
- Import into our platform
- Data mapping and transformation
- Verification and testing
- Migration report

**Data Volume:** Up to 10,000 records  
**Timeline:** 1-2 weeks  
**Best For:** Small to medium data migrations

### Enterprise Migration - ₹15,000
**Includes:**
- Large-scale data migration
- Complex data transformation
- Multiple data sources
- Data validation and deduplication
- Extended testing period
- Rollback plan
- 1 month post-migration support

**Data Volume:** Up to 100,000 records  
**Timeline:** 3-4 weeks  
**Best For:** Large organizations with complex data

### Custom Migration - Custom Pricing
**Includes:**
- Unlimited data volume
- Custom migration scripts
- Real-time migration options
- Zero-downtime migration
- Dedicated migration specialist
- Extended support period

**Timeline:** Custom based on requirements  
**Best For:** Enterprise customers with unique migration needs

### Migration Process
1. **Assessment**: Free assessment of data and requirements
2. **Planning**: Migration plan and timeline provided
3. **Preparation**: Data preparation and cleaning
4. **Migration**: Data transfer and import
5. **Validation**: Data verification and testing
6. **Support**: Post-migration support and training

---

## Priority Support Add-ons

### Priority Email Support - ₹2,499/month
**Includes:**
- Response time: 4-8 hours (vs standard 24-48 hours)
- Extended support hours (8 AM - 8 PM IST)
- Priority ticket queue
- Email support only

**Available For:** Basic and Premium plans

### Priority Support Plus - ₹4,999/month
**Includes:**
- Response time: 2-4 hours
- Extended support hours (7 AM - 9 PM IST)
- Priority ticket queue
- Email and live chat support
- Weekend support (Saturday)

**Available For:** Basic and Premium plans

### Dedicated Support - ₹10,000/month
**Includes:**
- Response time: Under 2 hours
- 24/7 email and chat support
- Dedicated support channel
- Assigned support specialist
- Proactive monitoring
- Monthly account review

**Available For:** Premium and Enterprise plans

### Enterprise Support Package - ₹20,000/month
**Includes:**
- Response time: Under 1 hour
- 24/7 phone, email, and chat support
- Dedicated support team
- Account manager access
- Proactive issue resolution
- Quarterly business reviews

**Available For:** Enterprise plans only

---

## Add-on Features

### Basic Add-on Package - ₹2,999/month
**Includes:**
- Additional reporting templates (10 templates)
- Extended data export formats
- Basic workflow automation (5 workflows)
- Additional custom fields (20 fields)

**Best For:** Basic plan customers needing more features

### Premium Add-on Package - ₹3,499/month
**Includes:**
- Advanced reporting suite (unlimited templates)
- Advanced workflow automation (unlimited workflows)
- Extended integrations (5 additional integrations)
- Advanced analytics dashboard
- Custom branding options

**Best For:** Premium plan customers wanting enterprise features

### Individual Add-ons
- **Additional Storage (25GB)**: ₹1,999/month
- **Extra User Licenses (5 users)**: ₹2,499/month
- **Advanced Analytics**: ₹1,999/month
- **Workflow Automation**: ₹1,499/month
- **Custom Branding**: ₹2,999/month (one-time setup)

---

## Professional Services

### Custom Development - Starting at ₹50,000
**Includes:**
- Custom feature development
- API development
- Custom modules and plugins
- Integration with proprietary systems
- Dedicated development team
- Project management
- Testing and QA
- Documentation

**Timeline:** Custom based on requirements  
**Best For:** Enterprise customers with unique needs

### Consulting Services - ₹5,000/hour
**Includes:**
- Platform optimization consulting
- Workflow design and optimization
- Best practices guidance
- Custom solution design
- Technical architecture review

**Minimum Engagement:** 4 hours  
**Best For:** Organizations needing expert guidance

### Implementation Services - Custom Pricing
**Includes:**
- Complete platform implementation
- Data migration
- Team training
- Workflow setup
- Integration configuration
- Go-live support
- Post-implementation review

**Timeline:** 4-12 weeks depending on scope  
**Best For:** New Enterprise customers

---

## Service Packages

### Starter Package - ₹15,000 (one-time)
**Includes:**
- Onboarding training (2 hours)
- Standard data migration (up to 5,000 records)
- 1 month priority email support
- Basic add-on features (1 month)

**Best For:** New Basic/Premium customers

### Growth Package - ₹35,000 (one-time)
**Includes:**
- Advanced training (4 hours)
- Standard data migration (up to 10,000 records)
- Standard integration (1 integration)
- 3 months priority support
- Premium add-on features (3 months)

**Best For:** Growing businesses

### Enterprise Package - Custom Pricing
**Includes:**
- Enterprise training package
- Enterprise data migration
- Multiple custom integrations
- Dedicated support package
- Custom development (if needed)
- Implementation services
- Extended support period

**Best For:** Large Enterprise customers

---

## Service Availability

### Availability by Plan
- **Basic Plan**: Training, basic add-ons, standard migration
- **Premium Plan**: All services except Enterprise-only packages
- **Enterprise Plan**: All services including custom development

### Service Request Process
1. **Consultation**: Free consultation to discuss needs
2. **Proposal**: Detailed proposal with pricing and timeline
3. **Approval**: Customer approval and payment
4. **Delivery**: Service delivery according to timeline
5. **Support**: Post-service support as included

### Service Support
- **Training**: 1 week email support after training
- **Integrations**: 3-6 months support (varies by package)
- **Migrations**: 1 month post-migration support
- **Development**: Support included per project agreement

---

## Frequently Asked Questions

**Q: Can I purchase services if I'm on Basic plan?**
A: Yes, most services are available to all plans. Some Enterprise-only services require Enterprise subscription.

**Q: Are services refundable?**
A: Training and integration services are non-refundable once delivered. Migration services may be refundable if not started.

**Q: Can I get a discount for multiple services?**
A: Yes, service packages offer discounts. Enterprise customers can discuss custom pricing.

**Q: How do I request a service?**
A: Contact support or sales team. They'll provide a consultation and proposal.

**Q: Are services available globally?**
A: Online services are available globally. On-site services available in select regions.

---

## Contact for Services

**Sales Team:**
- Email: sales@example.com
- Phone: Available for Enterprise inquiries
- Response: Within 24 hours

**Support Team:**
- Email: support@example.com
- For service-related questions and requests


