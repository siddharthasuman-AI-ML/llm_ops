# Customer Profile: CUST-019

**Name:** Aditya Chaturvedi  
**Email:** aditya.chaturvedi@example.com  
**Phone:** +91-9123456785  
**Address:** 813 Koregaon Park, Pune, Maharashtra 411001  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 1  

## Recent Tickets:
1. Billing discrepancy report  

## Purchase History:
- Premium subscription (₹12,499) - 22 days ago
- Backup storage upgrade (₹1,999) - 38 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity (with additional 25GB from upgrade = 75GB total)
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

**Add-on Features Active:**
- Additional storage upgrade (25GB added)

