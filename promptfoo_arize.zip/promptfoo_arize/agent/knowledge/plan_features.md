# Plan Features and Pricing

## Overview
We offer three subscription plans designed to meet the needs of different customers, from individual users to large enterprises.

---

## Basic Plan - ₹4,999/month

### Features Included:
- **Dashboard Access**: Core dashboard with essential features
- **Reporting**: Basic reporting capabilities with standard templates
- **Support**: Email support during business hours (9 AM - 6 PM IST, Monday-Friday)
- **Storage**: 5GB of data storage
- **Users**: Up to 3 user accounts
- **Integrations**: Basic integrations with popular tools
- **Mobile Access**: Web-based mobile access
- **Data Export**: Standard data export functionality

### Limitations:
- No API access
- Standard support response time (24-48 hours)
- Basic integrations only (no custom integrations)
- Limited storage capacity
- No dedicated account manager
- No SLA guarantee

### Best For:
- Small teams and individual users
- Startups getting started
- Users with basic CRM needs
- Budget-conscious customers

### Upgrade Options:
- Can upgrade to Premium or Enterprise anytime
- Prorated billing on upgrades
- Data migration included free

---

## Premium Plan - ₹12,499/month

### Features Included:
- **Dashboard Access**: Advanced dashboard with premium features
- **Reporting**: Premium reporting with custom templates and advanced analytics
- **Support**: Priority email support with faster response times (12-24 hours)
- **Storage**: 50GB of data storage
- **Users**: Up to 15 user accounts
- **API Access**: Limited API access for integrations
- **Integrations**: Advanced integrations with extended capabilities
- **Mobile App**: Full-featured mobile app access (iOS and Android)
- **Data Export**: Advanced data export with custom formats
- **Backup**: Automated daily backups
- **Advanced Features**: Workflow automation, custom fields, advanced search

### Limitations:
- No custom integrations (standard integrations only)
- Standard SLA (no guaranteed uptime)
- No dedicated account manager
- Limited API rate limits

### Best For:
- Growing businesses
- Teams needing advanced features
- Companies requiring better support
- Organizations with moderate data needs

### Upgrade Options:
- Can upgrade to Enterprise for unlimited features
- Can add priority support add-on (₹2,499/month)
- Can purchase additional storage (₹1,999/month for 25GB)

---

## Enterprise Plan - ₹49,999/month

### Features Included:
- **Dashboard Access**: Full dashboard suite with all features unlocked
- **Reporting**: Custom reporting with unlimited templates and real-time analytics
- **Support**: 24/7 phone and email support with dedicated support team
- **Storage**: Unlimited data storage
- **Users**: Unlimited user accounts
- **API Access**: Full API access with no rate limits
- **Integrations**: Custom integrations and API development support
- **Mobile App**: Enterprise mobile app with advanced features
- **Data Export**: Unlimited data export with all formats
- **Backup**: Real-time backups with point-in-time recovery
- **Advanced Features**: All premium features plus:
  - Custom workflows and automation
  - Advanced security features (SSO, 2FA, audit logs)
  - White-label options
  - Custom branding
- **Account Management**: Dedicated account manager
- **SLA Guarantee**: 99.9% uptime SLA with compensation
- **Training**: Included training sessions (up to 4 sessions per year)
- **Onboarding**: Dedicated onboarding assistance

### Limitations:
- None - all features included

### Best For:
- Large organizations
- Enterprise customers
- Companies requiring custom solutions
- Organizations needing guaranteed uptime and support

### Additional Services Available:
- Custom development (₹15,000+)
- Additional training sessions (₹5,000-₹8,000 per session)
- Extended support packages (₹10,000-₹20,000/month)

---

## Plan Comparison Summary

| Feature | Basic | Premium | Enterprise |
|---------|-------|---------|------------|
| **Price** | ₹4,999/month | ₹12,499/month | ₹49,999/month |
| **Storage** | 5GB | 50GB | Unlimited |
| **Users** | Up to 3 | Up to 15 | Unlimited |
| **Support** | Email (Business Hours) | Priority Email | 24/7 Phone + Email |
| **API Access** | No | Limited | Full |
| **Mobile App** | Web Access | Full App | Enterprise App |
| **Custom Integrations** | No | No | Yes |
| **Account Manager** | No | No | Yes |
| **SLA** | No | Standard | 99.9% Guaranteed |
| **Training** | No | No | Included |
| **Backup** | Manual | Daily Automated | Real-time |

---

## Add-on Services (Available for All Plans)

- **Add-on Features Package**: ₹2,999-₹3,499 (additional modules and extended features)
- **Priority Support**: ₹2,499-₹10,000/month (faster response times, dedicated channels)
- **Data Migration Service**: ₹6,999 (full data transfer with validation)
- **Training Sessions**: ₹5,000-₹8,000 per session (onboarding, advanced training)
- **Custom Integrations**: ₹15,000+ (API development, third-party connectors)
- **Storage Upgrades**: ₹1,999/month for 25GB additional storage (Basic/Premium)

---

## Plan Selection Guide

**Choose Basic if:**
- You're an individual or small team (1-3 users)
- You have basic CRM needs
- Budget is a primary concern
- You don't need API access

**Choose Premium if:**
- You're a growing business (4-15 users)
- You need advanced features and reporting
- You require better support and storage
- You need mobile app access

**Choose Enterprise if:**
- You're a large organization (15+ users)
- You need custom solutions and integrations
- You require guaranteed uptime and 24/7 support
- You need dedicated account management

---

## Upgrade and Downgrade Information

**Upgrading:**
- Upgrades are instant and take effect immediately
- Billing is prorated - you only pay the difference
- Data migration is included free
- No data loss during upgrade

**Downgrading:**
- Can downgrade at the end of billing cycle
- Data export available before downgrade
- Some features may be lost - check plan comparison
- Contact support for assistance with downgrade

---

## Frequently Asked Questions

**Q: Can I switch plans anytime?**
A: Yes, you can upgrade instantly or downgrade at the end of your billing cycle.

**Q: What happens to my data if I downgrade?**
A: Your data is preserved, but you may lose access to features not available in the lower plan. Export your data before downgrading if needed.

**Q: Do you offer annual plans?**
A: Yes, annual plans offer 2 months free (10% discount). Contact sales for annual pricing.

**Q: Can I get a custom plan?**
A: Enterprise customers can discuss custom pricing and features with their account manager.

**Q: What payment methods do you accept?**
A: We accept credit cards, debit cards, UPI, net banking, and wire transfers for Enterprise plans.


