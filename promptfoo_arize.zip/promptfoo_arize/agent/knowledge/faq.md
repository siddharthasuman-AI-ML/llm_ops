# Frequently Asked Questions (FAQ)

## Plan and Pricing Questions

### Q: How many plans do you offer?
**A:** We offer three subscription plans:
- **Basic Plan**: ₹4,999/month - For small teams and individuals
- **Premium Plan**: ₹12,499/month - For growing businesses
- **Enterprise Plan**: ₹49,999/month - For large organizations

Each plan includes different features, storage, support levels, and user limits.

---

### Q: What's included in the Basic plan?
**A:** The Basic plan (₹4,999/month) includes:
- Core dashboard access
- Basic reporting
- Email support (business hours)
- 5GB storage
- Up to 3 users
- Basic integrations
- Web-based mobile access

---

### Q: What's included in the Premium plan?
**A:** The Premium plan (₹12,499/month) includes:
- Advanced dashboard
- Premium reporting with analytics
- Priority email support (12-24 hour response)
- 50GB storage
- Up to 15 users
- Limited API access
- Advanced integrations
- Full mobile app (iOS and Android)
- Automated daily backups
- Workflow automation

---

### Q: What's included in the Enterprise plan?
**A:** The Enterprise plan (₹49,999/month) includes:
- Full dashboard suite with all features
- Custom reporting and real-time analytics
- 24/7 phone and email support
- Unlimited storage
- Unlimited users
- Full API access
- Custom integrations
- Enterprise mobile app
- Real-time backups
- Dedicated account manager
- 99.9% uptime SLA
- Included training sessions
- Advanced security (SSO, 2FA, audit logs)

---

### Q: Can I switch plans anytime?
**A:** Yes! You can upgrade instantly - changes take effect immediately and billing is prorated. Downgrades take effect at the end of your current billing cycle.

---

### Q: Do you offer annual plans?
**A:** Yes, annual plans offer 2 months free (10% discount). Contact sales for annual pricing details.

---

### Q: What payment methods do you accept?
**A:** We accept:
- Credit cards (Visa, Mastercard, American Express)
- Debit cards
- UPI (India)
- Net banking (India)
- Wire transfers (Enterprise annual plans)

---

## Upgrade and Downgrade Questions

### Q: How do I upgrade my plan?
**A:** To upgrade:
1. Go to your account settings
2. Select "Upgrade Plan"
3. Choose your new plan
4. Review pricing (prorated billing)
5. Confirm upgrade
6. Features activate immediately

Upgrades are instant with no downtime.

---

### Q: What happens when I upgrade?
**A:** When you upgrade:
- New features activate immediately
- Billing is prorated (you only pay the difference)
- Data migration is automatic and free
- No data loss or downtime
- You receive email confirmation

---

### Q: Can I downgrade my plan?
**A:** Yes, you can downgrade at any time. The downgrade takes effect at the end of your current billing cycle. Some features may no longer be available, so we recommend exporting your data before downgrading.

---

### Q: What happens to my data if I downgrade?
**A:** Your data is preserved, but you may lose access to features not available in the lower plan. We recommend exporting your data before downgrading. Data export is available in your account settings.

---

## Cancellation Questions

### Q: Can I cancel anytime?
**A:** Yes, you can cancel your subscription at any time with no penalties or fees. Cancellation takes effect at the end of your current billing period.

---

### Q: What happens to my data if I cancel?
**A:** After cancellation:
- Your account remains active until the end of the billing period
- You can export all your data (available in account settings)
- Data is retained for 30 days after cancellation
- You can reactivate within 30 days with all data intact
- After 30 days, data is permanently deleted

---

### Q: How do I cancel my subscription?
**A:** To cancel:
1. Go to account settings
2. Click "Cancel Subscription"
3. Confirm cancellation
4. Export your data (recommended)
5. Account remains active until end of billing period
6. Receive confirmation email

---

### Q: Can I reactivate my account after cancellation?
**A:** Yes, you can reactivate within 30 days of cancellation with all your data intact. After 30 days, data is permanently deleted and you'll need to start fresh.

---

## Refund Questions

### Q: What is your refund policy?
**A:** We offer:
- **30-day money-back guarantee** for new subscriptions
- Full refund if not satisfied within first 30 days
- Pro-rated refunds for annual plans
- Refunds processed within 5-7 business days

---

### Q: How do I request a refund?
**A:** Contact support via email or phone, provide your subscription details, and we'll process the refund to your original payment method within 5-7 business days.

---

### Q: Are add-ons refundable?
**A:** Add-ons are refundable if unused within 30 days of purchase. Training and integration services are non-refundable once delivered.

---

## Support Questions

### Q: What support do I get with my plan?
**A:** Support varies by plan:
- **Basic**: Email support, 24-48 hour response, business hours
- **Premium**: Priority email support, 12-24 hour response, business hours
- **Enterprise**: 24/7 phone and email support, under 2 hour response

---

### Q: How do I contact support?
**A:** You can contact support via:
- Email: support@example.com
- Phone: Available for Enterprise customers
- Live Chat: Available for Premium and Enterprise (business hours)
- Help Center: Self-service knowledge base

---

### Q: What are your support hours?
**A:** Support hours vary by plan:
- **Basic**: 9 AM - 6 PM IST, Monday-Friday
- **Premium**: 9 AM - 6 PM IST, Monday-Friday (extended with add-on)
- **Enterprise**: 24/7 support

---

### Q: Can I get faster support?
**A:** Yes, Priority Support add-ons are available:
- Priority Email Support: ₹2,499/month (4-8 hour response)
- Priority Support Plus: ₹4,999/month (2-4 hour response)
- Dedicated Support: ₹10,000/month (under 2 hour response)

---

## API and Integration Questions

### Q: Do you offer API access?
**A:** API access varies by plan:
- **Basic**: No API access
- **Premium**: Limited API access
- **Enterprise**: Full API access with no rate limits

---

### Q: How do I access API documentation?
**A:** API documentation is available in your account dashboard for Premium and Enterprise customers. Enterprise customers also receive dedicated API support.

---

### Q: What integrations are available?
**A:** We offer:
- **Basic Plan**: Basic integrations with popular tools
- **Premium Plan**: Advanced integrations with extended capabilities
- **Enterprise Plan**: Custom integrations and API development support

Popular integrations include CRM systems, email marketing tools, accounting software, and more.

---

### Q: Can I get custom integrations?
**A:** Yes, custom integration services are available:
- Standard Integration: ₹15,000 (one third-party service)
- Advanced Integration: ₹30,000 (complex multi-service)
- Enterprise Integration Package: Custom pricing

---

## Data and Security Questions

### Q: How secure is my data?
**A:** We take data security seriously:
- All data encrypted in transit and at rest
- Regular automated backups
- Role-based access control
- Audit logs (Enterprise)
- GDPR compliant
- Secure data centers

---

### Q: Can I export my data?
**A:** Yes, full data export is available for all plans:
- Export formats: CSV, JSON, Excel
- Available in account settings
- Processed within 48 hours
- No limits on export frequency

---

### Q: Where is my data stored?
**A:** Data is stored in secure, compliant data centers. Enterprise customers can discuss data residency requirements with their account manager.

---

### Q: Who has access to my data?
**A:** Only you and authorized team members have access to your data. Our support team can access your account only with your explicit permission for troubleshooting purposes.

---

## Billing Questions

### Q: When am I billed?
**A:** Billing occurs:
- **Monthly plans**: Same date each month
- **Annual plans**: Once per year
- **Enterprise**: Custom billing cycles available

---

### Q: What happens if my payment fails?
**A:** If payment fails:
- We automatically retry 3 times over 7 days
- You receive email notifications for each attempt
- Account remains active during retry period
- Account suspended after 7 days of failed payment
- Reactivate by updating payment method

---

### Q: Can I get an invoice?
**A:** Yes, invoices are:
- Automatically sent via email after each payment
- Available in PDF format
- Downloadable from account settings
- Include GST/VAT as applicable

---

## Service Questions

### Q: What additional services do you offer?
**A:** We offer:
- **Training**: ₹5,000-₹8,000 per session (onboarding, advanced)
- **Custom Integrations**: ₹15,000+ (API development, connectors)
- **Data Migration**: ₹6,999+ (full data transfer)
- **Priority Support**: ₹2,499-₹10,000/month (faster response)
- **Add-on Features**: ₹2,999-₹3,499/month (additional modules)

---

### Q: Do you offer training?
**A:** Yes, we offer:
- Onboarding Training: ₹5,000 (2 hours)
- Advanced Training: ₹8,000 (4 hours)
- Enterprise Training Package: ₹25,000 (multiple sessions)

Training available online or on-site for Enterprise customers.

---

### Q: Can you help migrate my data?
**A:** Yes, data migration services available:
- Standard Migration: ₹6,999 (up to 10,000 records)
- Enterprise Migration: ₹15,000 (up to 100,000 records)
- Custom Migration: Custom pricing (unlimited volume)

Includes data cleaning, validation, import, and verification.

---

## General Questions

### Q: Is there a free trial?
**A:** We offer a 30-day money-back guarantee instead of a free trial. You can subscribe and get a full refund within 30 days if not satisfied.

---

### Q: Can I get a custom plan?
**A:** Enterprise customers can discuss custom pricing and features with their account manager. Custom plans available for large organizations with unique needs.

---

### Q: Do you offer discounts?
**A:** Yes:
- Annual plans: 2 months free (10% discount)
- Service packages: Discounts for multiple services
- Enterprise: Custom pricing available

---

### Q: What happens during maintenance?
**A:** Scheduled maintenance:
- Advance notice provided (usually 48 hours)
- Minimal downtime
- Performed during low-traffic hours
- Updates and improvements included
- Enterprise customers receive priority notification

---

## Still Have Questions?

**Contact Support:**
- Email: support@example.com
- Phone: Available for Enterprise customers
- Help Center: Self-service knowledge base
- Community Forum: Peer support and discussions

**Contact Sales:**
- Email: sales@example.com
- For plan questions and Enterprise inquiries


