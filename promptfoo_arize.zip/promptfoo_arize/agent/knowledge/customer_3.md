# Customer Profile: CUST-003

**Name:** Amit Kumar  
**Email:** amit.kumar@example.com  
**Phone:** +91-9988776655  
**Address:** 789 Connaught Place, New Delhi, Delhi 110001  
**Plan Type:** Enterprise  
**Last Purchase:** ₹49,999  
**Open Tickets:** 1  

## Recent Tickets:
1. Request for API access documentation  

## Purchase History:
- Enterprise license (₹49,999) - 10 days ago
- Custom integration service (₹15,000) - 20 days ago
- Training session (₹5,000) - 25 days ago

## Plan Features Access:
**Enterprise Plan Features:**
- Full dashboard suite with all features unlocked
- Custom reporting with unlimited templates and real-time analytics
- 24/7 phone and email support with dedicated support team
- Unlimited data storage
- Unlimited user accounts
- Full API access with no rate limits
- Custom integrations and API development support
- Enterprise mobile app with advanced features
- Unlimited data export with all formats
- Real-time backups with point-in-time recovery
- All premium features plus:
  - Custom workflows and automation
  - Advanced security features (SSO, 2FA, audit logs)
  - White-label options
  - Custom branding
- Dedicated account manager
- 99.9% uptime SLA guarantee
- Included training sessions (up to 4 sessions per year)
- Dedicated onboarding assistance

**Additional Services Active:**
- Custom integration service configured
- Training session completed

