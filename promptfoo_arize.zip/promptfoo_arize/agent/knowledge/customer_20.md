# Customer Profile: CUST-020

**Name:** Pooja Mehta  
**Email:** pooja.mehta@example.com  
**Phone:** +91-9876543216  
**Address:** 924 Jubilee Hills, Hyderabad, Telangana 500033  
**Plan Type:** Enterprise  
**Last Purchase:** ₹49,999  
**Open Tickets:** 2  

## Recent Tickets:
1. Multi-user access configuration  
2. Security audit report request  

## Purchase History:
- Enterprise license (₹49,999) - 6 days ago
- Advanced security features (₹15,000) - 11 days ago
- Training workshop (₹8,000) - 18 days ago

## Plan Features Access:
**Enterprise Plan Features:**
- Full dashboard suite with all features unlocked
- Custom reporting with unlimited templates and real-time analytics
- 24/7 phone and email support with dedicated support team
- Unlimited data storage
- Unlimited user accounts
- Full API access with no rate limits
- Custom integrations and API development support
- Enterprise mobile app with advanced features
- Unlimited data export with all formats
- Real-time backups with point-in-time recovery
- All premium features plus advanced security, white-label, custom branding
- Dedicated account manager
- 99.9% uptime SLA guarantee
- Included training sessions (up to 4 sessions per year)
- Dedicated onboarding assistance

**Additional Services Active:**
- Advanced security features (SSO, 2FA, enhanced audit logs)
- Advanced training workshop completed

