# Customer Profile: CUST-017

**Name:** Karan Malhotra  
**Email:** karan.malhotra@example.com  
**Phone:** +91-9876543215  
**Address:** 681 DLF Cyber City, Gurgaon, Haryana 122002  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 3  

## Recent Tickets:
1. Performance optimization request  
2. Mobile app crash report  
3. Feature enhancement suggestion  

## Purchase History:
- Premium subscription (₹12,499) - 14 days ago
- Premium support add-on (₹2,499) - 32 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

**Add-on Features Active:**
- Priority Email Support (4-8 hour response, extended hours)

