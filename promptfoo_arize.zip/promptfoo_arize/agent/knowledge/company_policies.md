# Company Policies

## Refund Policy

### Money-Back Guarantee
- **30-Day Guarantee**: All new subscriptions come with a 30-day money-back guarantee
- **Full Refund**: If you're not satisfied within the first 30 days, receive a full refund
- **No Questions Asked**: Refund requests are processed without requiring explanations
- **Processing Time**: Refunds are processed within 5-7 business days

### Pro-Rated Refunds
- **Annual Plans**: Pro-rated refunds available for unused months on annual subscriptions
- **Calculation**: Refund amount = (Remaining months / Total months) × Total paid amount
- **Processing**: Pro-rated refunds processed within 7-10 business days

### Refund Eligibility
- **New Subscriptions**: Eligible for full refund within 30 days
- **Renewals**: Not eligible for refund (can cancel before renewal)
- **Add-ons**: Refundable if unused within 30 days of purchase
- **Services**: Training and integration services are non-refundable once delivered

### How to Request a Refund
1. Contact support via email or phone
2. Provide subscription details
3. Refund will be processed to original payment method
4. Confirmation email sent upon processing

---

## Upgrade Policy

### Instant Upgrades
- **Immediate Access**: Upgrades take effect immediately upon payment
- **No Downtime**: Seamless transition with no service interruption
- **Feature Access**: All new features available immediately

### Prorated Billing
- **Calculation**: You only pay the difference between plans
- **Example**: If you upgrade mid-month, you pay: (New Plan Price - Current Plan Price) × (Remaining Days / Total Days)
- **Billing Cycle**: Upgrade charges appear on next billing cycle

### Data Migration
- **Included Free**: Data migration is included with all upgrades
- **Automatic**: Most data migrates automatically
- **Assistance**: Support team available to help with complex migrations
- **Timeline**: Migration typically completes within 24-48 hours

### Upgrade Process
1. Select new plan in account settings
2. Review pricing and features
3. Confirm upgrade
4. Payment processed (prorated)
5. Features activated immediately

---

## Cancellation Policy

### Cancel Anytime
- **No Contracts**: All plans are month-to-month with no long-term contracts
- **Cancel Anytime**: Cancel your subscription at any time
- **No Penalties**: No cancellation fees or penalties
- **Effective Date**: Cancellation takes effect at the end of current billing period

### Data Export
- **Available**: Full data export available before cancellation
- **Formats**: Export available in CSV, JSON, Excel formats
- **Timeline**: Export requests processed within 48 hours
- **Instructions**: Step-by-step guide provided for data export

### Data Retention
- **30-Day Retention**: Account data retained for 30 days after cancellation
- **Recovery**: Can reactivate account within 30 days with full data recovery
- **After 30 Days**: Data is permanently deleted and cannot be recovered
- **Backup**: Download your data before cancellation to keep permanently

### Cancellation Process
1. Go to account settings
2. Click "Cancel Subscription"
3. Confirm cancellation
4. Export data (optional but recommended)
5. Account remains active until end of billing period
6. Receive confirmation email

### Reactivation
- **Within 30 Days**: Can reactivate with all data intact
- **After 30 Days**: Must start fresh (data deleted)
- **Process**: Contact support to reactivate account

---

## Support Policy

### Response Times by Plan

**Basic Plan:**
- Email Support: 24-48 hours response time
- Business Hours: 9 AM - 6 PM IST, Monday-Friday
- No phone support
- Standard support channels only

**Premium Plan:**
- Priority Email Support: 12-24 hours response time
- Business Hours: 9 AM - 6 PM IST, Monday-Friday
- Extended hours available with add-on (₹2,499/month)
- Priority ticket handling

**Enterprise Plan:**
- 24/7 Phone and Email Support
- Response Time: Under 2 hours for critical issues
- Dedicated support team
- Escalation to account manager available

### Support Channels
- **Email**: support@example.com
- **Phone**: Available for Enterprise customers (24/7)
- **Live Chat**: Available for Premium and Enterprise (business hours)
- **Help Center**: Self-service knowledge base for all customers
- **Community Forum**: Peer support and discussions

### Escalation Procedures
1. **Level 1**: Standard support team (all plans)
2. **Level 2**: Senior support specialists (Premium/Enterprise)
3. **Level 3**: Account manager (Enterprise only)
4. **Level 4**: Technical team lead (critical issues)

### Support Scope
- **Included**: Account issues, billing questions, feature guidance, bug reports
- **Not Included**: Custom development, extensive training, third-party integrations (available as paid services)

---

## Billing Policy

### Billing Cycles
- **Monthly**: Billed monthly on the same date each month
- **Annual**: Billed once per year with 2 months free (10% discount)
- **Enterprise**: Custom billing cycles available (quarterly, semi-annual)

### Payment Methods
- **Credit Cards**: Visa, Mastercard, American Express
- **Debit Cards**: All major debit cards accepted
- **UPI**: Unified Payments Interface (India)
- **Net Banking**: All major Indian banks
- **Wire Transfer**: Available for Enterprise annual plans

### Invoice Details
- **Automatic Invoices**: Sent via email after each payment
- **Invoice Format**: PDF format with company details
- **Tax Information**: GST/VAT included as applicable
- **Payment Receipts**: Available in account dashboard
- **Download**: Invoices downloadable from account settings

### Payment Failures
- **Retry Attempts**: Automatic retry for failed payments (3 attempts over 7 days)
- **Notification**: Email notification sent for each failed attempt
- **Account Status**: Account remains active during retry period
- **Suspension**: Account suspended after 7 days of failed payment
- **Reactivation**: Reactivate by updating payment method

### Refunds and Credits
- **Processing Time**: 5-7 business days for refunds
- **Method**: Refunded to original payment method
- **Credits**: Account credits available for service issues
- **Disputes**: Contact billing team for payment disputes

### Billing Questions
- **Contact**: billing@example.com
- **Response Time**: Within 24 hours
- **Disputes**: Resolved within 5 business days
- **Documentation**: All invoices and receipts available in account

---

## Data and Privacy Policy

### Data Security
- **Encryption**: All data encrypted in transit and at rest
- **Backups**: Regular automated backups (frequency varies by plan)
- **Access Control**: Role-based access control for team accounts
- **Audit Logs**: Available for Enterprise plans

### Data Ownership
- **Customer Owned**: You own all your data
- **Export Rights**: Full data export available anytime
- **Deletion**: Data deleted upon request (after retention period)
- **Third-Party Access**: No third-party access without consent

### Privacy Compliance
- **GDPR Compliant**: European data protection standards
- **Data Residency**: Data stored in secure data centers
- **Privacy Policy**: Full privacy policy available on website
- **Data Processing**: Transparent data processing practices

---

## Service Level Agreement (SLA)

### Uptime Guarantee (Enterprise Only)
- **99.9% Uptime**: Guaranteed 99.9% uptime per month
- **Monitoring**: 24/7 system monitoring
- **Incident Response**: Under 1 hour response time for outages
- **Compensation**: Service credits for SLA violations

### Performance Standards
- **Response Time**: API response times under 200ms (95th percentile)
- **Availability**: System available 24/7 except scheduled maintenance
- **Maintenance**: Scheduled maintenance with advance notice
- **Updates**: Regular updates and improvements

### SLA Exclusions
- Scheduled maintenance windows
- Customer-caused issues
- Third-party service outages
- Force majeure events

---

## Terms of Service Highlights

### Acceptable Use
- **Business Use**: Intended for legitimate business purposes
- **Prohibited**: Spam, illegal activities, abuse of system
- **Compliance**: Must comply with all applicable laws
- **Violations**: Account suspension for policy violations

### Account Responsibility
- **Security**: Responsible for maintaining account security
- **Credentials**: Keep login credentials secure
- **Activity**: Responsible for all account activity
- **Reporting**: Report suspicious activity immediately

### Service Modifications
- **Updates**: Service may be updated or modified
- **Notice**: Advance notice for significant changes
- **Discontinuation**: Right to discontinue service with notice
- **Migration**: Assistance provided for service changes

---

## Contact Information

**General Support:**
- Email: support@example.com
- Phone: Available for Enterprise customers
- Hours: Varies by plan (see Support Policy)

**Billing:**
- Email: billing@example.com
- Response: Within 24 hours

**Enterprise Sales:**
- Email: sales@example.com
- Phone: Available for Enterprise inquiries

**Privacy/Data:**
- Email: privacy@example.com
- For data-related inquiries and GDPR requests


