# Customer Profile: CUST-001

**Name:** Rahul Sharma  
**Email:** rahul.sharma@example.com  
**Phone:** +91-9876543210  
**Address:** 123 MG Road, Mumbai, Maharashtra 400001  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 2  

## Recent Tickets:
1. Unable to access premium dashboard  
2. Payment failure notification  

## Purchase History:
- Premium subscription renewal (₹12,499) - 15 days ago
- Add-on features package (₹2,999) - 45 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

**Add-on Features Active:**
- Additional reporting templates
- Extended workflow automation
- Advanced analytics dashboard

