# Customer Profile: CUST-010

**Name:** Kavita Joshi  
**Email:** kavita.joshi@example.com  
**Phone:** +91-9123456782  
**Address:** 741 Bandra West, Mumbai, Maharashtra 400050  
**Plan Type:** Basic  
**Last Purchase:** ₹4,999  
**Open Tickets:** 2  

## Recent Tickets:
1. Account upgrade inquiry  
2. Feature availability question  

## Purchase History:
- Basic subscription (₹4,999) - 90 days ago

## Plan Features Access:
**Basic Plan Features:**
- Core dashboard with essential features
- Basic reporting with standard templates
- Email support during business hours (9 AM - 6 PM IST, Monday-Friday)
- 5GB data storage
- Up to 3 user accounts
- Basic integrations with popular tools
- Web-based mobile access
- Standard data export functionality
- Manual backup options

