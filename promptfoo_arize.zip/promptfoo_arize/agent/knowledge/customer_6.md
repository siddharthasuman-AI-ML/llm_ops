# Customer Profile: CUST-006

**Name:** Anjali Desai  
**Email:** anjali.desai@example.com  
**Phone:** +91-9876543211  
**Address:** 987 Koregaon Park, Pune, Maharashtra 411001  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 1  

## Recent Tickets:
1. Request for refund processing  

## Purchase History:
- Premium subscription (₹12,499) - 20 days ago
- Premium add-on (₹3,499) - 35 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

**Add-on Features Active:**
- Advanced reporting suite (unlimited templates)
- Advanced workflow automation (unlimited workflows)
- Extended integrations (5 additional integrations)
- Advanced analytics dashboard
- Custom branding options

