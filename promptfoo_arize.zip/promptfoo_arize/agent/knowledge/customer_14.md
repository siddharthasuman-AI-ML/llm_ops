# Customer Profile: CUST-014

**Name:** Divya Krishnan  
**Email:** divya.krishnan@example.com  
**Phone:** +91-9876543214  
**Address:** 357 Adyar, Chennai, Tamil Nadu 600020  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 2  

## Recent Tickets:
1. Data export functionality question  
2. Integration API documentation request  

## Purchase History:
- Premium subscription (₹12,499) - 25 days ago
- Data migration service (₹6,999) - 50 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

**Additional Services Active:**
- Data migration service completed (up to 10,000 records migrated)

