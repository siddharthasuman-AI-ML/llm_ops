# Customer Profile: CUST-009

**Name:** Arjun Menon  
**Email:** arjun.menon@example.com  
**Phone:** +91-9876543212  
**Address:** 369 Banjara Hills, Hyderabad, Telangana 500034  
**Plan Type:** Premium  
**Last Purchase:** ₹12,499  
**Open Tickets:** 0  

## Recent Tickets:
None

## Purchase History:
- Premium subscription (₹12,499) - 12 days ago
- Advanced analytics module (₹4,999) - 28 days ago

## Plan Features Access:
**Premium Plan Features:**
- Advanced dashboard with premium features
- Premium reporting with custom templates and analytics
- Priority email support (12-24 hour response time)
- 50GB storage capacity
- Up to 15 user accounts
- Limited API access for integrations
- Advanced integrations with extended capabilities
- Full-featured mobile app (iOS and Android)
- Advanced data export with custom formats
- Automated daily backups
- Workflow automation capabilities
- Advanced search and custom fields

**Add-on Features Active:**
- Advanced analytics dashboard module

